import java.util.Scanner;

interface LogicGates{ //interface 
	public void ANDlogic();
	public void ORlogic();
	public void XORlogic();
	public void NOTlogic();
	public void NANDlogic();
}

class Gates implements LogicGates{ //implementing interface

	unsigned int a , b , c;
	Scanner sc = new Scanner(System.in);
	public void ANDlogic(){
		System.out.println("Enter the two numbers you want to perform a Bitwise AND operation");
		a = sc.nextInt();
		b = sc.nextInt();
		c = a & b;
		System.out.println(c);
	}

	public void ORlogic(){ // method for OR gate
		System.out.println("Enter the two numbers you want to perform a Bitwise AND operation");
		a = sc.nextInt();
		b = sc.nextInt();
		c = a | b;
		System.out.println(c);
	}

	public void NANDlogic(){// method for Nand gate
		System.out.println("Enter the two numbers you want to perform a Bitwise AND operation");
		a = sc.nextInt();
		b = sc.nextInt();
		c = ~(a&b);
		System.out.println(c);
	}

	public void XORlogic(){// method for XOR gate
		System.out.println("Enter the two numbers you want to perform a Bitwise AND operation");
		a = sc.nextInt();
		b = sc.nextInt();
		c = (a^b);
		System.out.println(c);
	}

	public void NOTlogic(){// method for NOT gate
		System.out.println("Enter the number you want to perform a Bitwise NOT operation");
		a = sc.nextInt();
		c = ~a;
		System.out.println(c);
	}

}

public class TestGates
{
	
	public static void main(String[] args) //main function of implmentation of gates
	{
		int option;
		Gates g = new Gates();
		Scanner sc = new Scanner(System.in);
		do
		{
			System.out.println("Choose your Option\n1)AND Operation\n2)OR Operation\n3)NOT Operation\n4)NAND Operation\n5)XOR Operation\n6)Exit");
			option = sc.nextInt();
			switch(option)
			{
				case 1:
					g.ANDlogic();
					break;
				case 2:
					g.ORlogic();
					break;
				case 3:
					g.NOTlogic();
					break;
				case 4:
					g.NANDlogic();
					break;
				case 5:
					g.XORlogic();
					break;
				case 6:
					System.out.println("You have successfully exited the Application");
					break;
				default:
					System.out.println("Please Choose a correct Option");
					break;
			
			}
		}while(option!=6);
	}
}


