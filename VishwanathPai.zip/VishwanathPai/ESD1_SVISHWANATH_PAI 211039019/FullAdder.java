import java.lang.*;//for input outupt
import java.util.*;//for scanner class

public class FullAdder{
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the 1st Bit number");//enter the first bit 
		int a = sc.nextInt();
		System.out.println("Enter the 2nd Bit number");//enter the second bit
		int b = sc.nextInt();
		System.out.println("Enter the the carry bit");//enter the carry bit
		int cin = sc.nextInt();

		int sum = a^b^cin; // sum= A xor B xor Carry
		int cout = a&b|b&cin|cin&a; 

		System.out.println("The Sum generated is : " + sum);
		System.out.println("The Carry generated is : " + cout);
	}
	
	}