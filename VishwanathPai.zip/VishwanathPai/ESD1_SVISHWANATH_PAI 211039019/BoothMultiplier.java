import java.util.Scanner;
 
public class BoothMultiplier
{
    public static Scanner s = new Scanner(System.in);

    //Method to multiply
    public int multiply(int n1, int n2)
    {
        int[] m = binary(n1);
        int[] m1 = binary(-n1);
        int[] r = binary(n2);        
        int[] A = new int[9];
        int[] S = new int[9];
        int[] P = new int[9];        
        for (int i = 0; i < 4; i++)      // multiply two 4 bit number gives 8 bit result
        {
            A[i] = m[i];
            S[i] = m1[i];
            P[i + 4] = r[i];
        }
        display(A, 'A');
        display(S, 'S');
        display(P, 'P');        
        System.out.println();
        

        
        for (int i = 0; i < 4; i++)// Checking the LSB and fictious bit to perform the necessary action
        {
            if (P[7] == 0 && P[8] == 0);
                // do nothing            
            else if (P[7] == 1 && P[8] == 0)
                add(P, S);                            
            else if (P[7] == 0 && P[8] == 1)
                add(P, A);            
            else if (P[7] == 1 && P[8] == 1);
                // do nothing
 
            rightShift(P);  // right shift is done after any operation
            display(P, 'P');
        }
        return getDecimal(P);
    }

   
    public int getDecimal(int[] B) //Methpd to get Decimal equivalent of P
    {
        int p = 0;
        int t = 1;
        for (int i = 7; i >= 0; i--, t *= 2)
            p += (B[i] * t);
        if (p > 64)
            p = -(256 - p);
        return p;        
    }

   
    public void rightShift(int[] A) //Method to right shift array
    {        
        for (int i = 8; i >= 1; i--)
            A[i] = A[i - 1];        
    }


    
    public void add(int[] A, int[] B)//Method to add two binary arrays
    {
        int carry = 0;
        for (int i = 8; i >= 0; i--)
        {
            int temp = A[i] + B[i] + carry;
            A[i] = temp % 2;
            carry = temp / 2;
        }        
    }
   
    public int[] binary(int n) //Method to get binary of a number
    {
        int[] bin = new int[4];
        int ctr = 3;
        int num = n;
        
        if (n < 0)// for negative numbers 2 complment
            num =                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 + n;
        while (num != 0)
        {
            bin[ctr--] = num % 2;
            num /= 2;
        }
        return bin;
    }

    
    public void display(int[] P, char ch)//Method to print array
    { 
        System.out.print("\n"+ ch +" : ");
        for (int i = 0; i < P.length; i++)
        {
            if (i == 4)
                System.out.print(" ");
            if (i == 8)
                System.out.print(" ");
            System.out.print(P[i]);
        } 
    }
    
    public static void main (String[] args) //Main function
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Booth Algorithm Test\n");

        BoothMultiplier b = new BoothMultiplier();
 
        
        System.out.println("Enter two integer numbers\n");//to get two integers from the user
        int n1 = scan.nextInt();
        int n2 = scan.nextInt();
        int result = b.multiply(n1, n2);
        System.out.println("\n\nResult : "+ n1 +" * "+ n2 +" = "+ result);                    
    }
}