import java.util.*;
import java.lang.*;

interface Geometry{ //interface
	public void square();
	public void rectangle();
	public void circle();
}

class Shapes implements Geometry{ //calling the method interface
	public void square(){
		Scanner sc = new Scanner(System.in);
		System.out.println(" Enter the Side of the Square");
		float side = sc.nextFloat();
		Float area_square = side*side; 

		System.out.println(" The Area of the Square is " + area_square);
	}

	public void rectangle(){ //method to find the area of rectangle
		Scanner sc = new Scanner(System.in);

		System.out.println(" Enter the length of the rectangle");
		float length = sc.nextFloat();
		System.out.println(" Enter the breadth of the rectangle");
		float breadth = sc.nextFloat();

		Float area_rectangle = length*breadth; 

		System.out.println(" The Area of the Rectangle is " + area_rectangle);
	}

	public void circle(){ //method to find the area of  Circle
		Scanner sc = new Scanner(System.in);

		System.out.println(" Enter the radius of the rectangle");
		float radius = sc.nextFloat();
		double area_circle = Math.PI*Math.pow(radius,2); 
		System.out.println(" The Area of the Circle is " + area_circle);
	}

}

public class Geometry1{ // main function
	public static void main(String[] args) {
		Geometry g = new Shapes();

		g.square();
		g.rectangle();
		g.circle();
	}
}
